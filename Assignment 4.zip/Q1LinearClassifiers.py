import pandas as pd
from numpy import var
from numpy import mean
from sklearn.linear_model import *
from sklearn.model_selection import train_test_split
from sklearn.metrics import *
from sklearn.svm import LinearSVC

#Read in both csv files into a dataframe
ds1 = pd.read_csv('ds1.csv', header=None, delimiter=',')

#Convert file data into list format to perform operations
x = ds1[[0, 1]].values.tolist()
y = ds1[2].values.tolist()

#Split our data into a training and testing set
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.3, random_state=1)

#We want to compare linear models, so below we are running a handful of discussed linear models
#for comparison against each other using loss functions

#Linear Regression with loss functions
lin = LinearRegression().fit(xtrain, ytrain)
ypred = lin.predict(xtest)
print('Linear Regression Loss Functions')
print('Squared Loss: ', mean_squared_error(ytest, ypred))
print('Absolute loss: ', mean_absolute_error(ytest, ypred))
print()

#Logistic Regression with loss functions
log = LogisticRegression().fit(xtrain, ytrain)
ypred = log.predict(xtest)
print('Logistic Regression Loss Functions')
print('Zero-One loss: ', zero_one_loss(ytest, ypred))
print('Squared Loss: ', mean_squared_error(ytest, ypred))
print('Absolute loss: ', mean_absolute_error(ytest, ypred))
print()

#Perceptron with loss functions
per = Perceptron().fit(xtrain, ytrain)            
ypred = per.predict(xtest)
yhinge = per.decision_function(xtest)
print('Perceptron Loss Functions')
print('Hinge Loss: ', hinge_loss(ytest, yhinge))
print('Zero-One loss: ', zero_one_loss(ytest, ypred))
print('Squared Loss: ', mean_squared_error(ytest, ypred))
print('Absolute loss: ', mean_absolute_error(ytest, ypred))

#Perceptron with Regularizations
print('Perceptron Accuracies')
print('No Penalty: ', accuracy_score(ytest, ypred))
per = Perceptron(penalty='l2').fit(xtrain, ytrain)            
ypred = per.predict(xtest)
print('L2: ', accuracy_score(ytest, ypred))
per = Perceptron(penalty='elasticnet').fit(xtrain, ytrain)            
ypred = per.predict(xtest)
print('Elasticnet: ', accuracy_score(ytest, ypred))
print()

#SGDC with loss functions
grad = SGDClassifier().fit(xtrain, ytrain)           
ypred = grad.predict(xtest)
yhinge = per.decision_function(xtest)
print('SGDC Loss Functions')
print('Hinge Loss: ', hinge_loss(ytest, yhinge))
print('Zero-One loss: ', zero_one_loss(ytest, ypred))
print('Squared Loss: ', mean_squared_error(ytest, ypred))
print('Absolute loss: ', mean_absolute_error(ytest, ypred))

#SGDC with Regularizations
print('SGDC Accuracies')
print('No Penalty: ', accuracy_score(ytest, ypred))
per = SGDClassifier(penalty='l2').fit(xtrain, ytrain)            
ypred = grad.predict(xtest)
print('L2: ', accuracy_score(ytest, ypred))
per = SGDClassifier(penalty='elasticnet').fit(xtrain, ytrain)            
ypred = grad.predict(xtest)
print('Elasticnet: ', accuracy_score(ytest, ypred))
print()

#Linear SVM with loss functions
svm = LinearSVC().fit(xtrain, ytrain)           
ypred = svm.predict(xtest)
yhinge = per.decision_function(xtest)
print('SVM Loss Functions')
print('Hinge Loss: ', hinge_loss(ytest, yhinge))
print('Zero-One loss: ', zero_one_loss(ytest, ypred))
print('Squared Loss: ', mean_squared_error(ytest, ypred))
print('Absolute loss: ', mean_absolute_error(ytest, ypred))

#SVM with Regularizations
print('SVM Accuracies')
print('No Penalty: ', accuracy_score(ytest, ypred))
svm = SGDClassifier(penalty='l2').fit(xtrain, ytrain)            
ypred = svm.predict(xtest)
print('L2: ', accuracy_score(ytest, ypred))
svm = SGDClassifier(penalty='elasticnet').fit(xtrain, ytrain)            
ypred = svm.predict(xtest)
print('Elasticnet: ', accuracy_score(ytest, ypred))
print()
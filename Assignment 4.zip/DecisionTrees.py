import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

#Read in ds3.csv for use in creating a decision tree
ds3 = pd.read_csv('ds3.csv', header=None, delimiter=',')

#Convert file data into list format to perform operations
x = ds3[[0, 1]].values.tolist()
y = ds3[2].values.tolist()

#Split our data into a training and testing set
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.3, random_state=1)

clf = DecisionTreeClassifier()

clf = clf.fit(xtrain, ytrain)

ypred = clf.predict(xtest)

print("accuracy: ", accuracy_score(ytest, ypred))
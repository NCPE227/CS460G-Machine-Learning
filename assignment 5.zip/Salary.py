from pandas import read_csv

from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression, LogisticRegression, Perceptron, SGDClassifier
from sklearn.metrics import accuracy_score, hinge_loss, mean_absolute_error, mean_squared_error, zero_one_loss
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor


place = read_csv("Placement_Data_Full_Class.csv", header=None, skiprows=1, delimiter=',')

#Let's change string values to numerical ones
mymap = {'M':0, 'F':1, 'Others':0, 'Central':1, 'Arts':0, 'Commerce':1, 'Science':2, 'Comm&Mgmt':0,
'Others':1, 'Sci&Tech':2, 'No':0, 'Yes':1, 'Mkt&Fin':0, 'Mkt&HR':1, 'Placed':1, 'Not Placed':0}

place = place.applymap(lambda s: mymap.get(s) if s in mymap else s)
place[14] = place[14].fillna(0)

#Format X so that we can get a list of values without the status values since those are needed for the y dataset
x = place
x.drop([14], axis=1)
x.values.tolist()

#now we take the dropped column and add it as a list for our y database
y = place[14].values.tolist()

#Split the data into training and testing sets
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.3, random_state=1)


#Lets create a list to contain results from each of the tests to printout later for comparison
losses = [['Classifier Name', 'Hinge Loss', 'Zero-One Loss', 'Squared Loss', 'Absolute Loss']] #this 2d array will contain losses for each classified using the shown format
# [ Classifier Name, Hinge Loss, Zero-One Loss, Squared Loss, Absolute Loss ]
accuracies = [['Classifier Name', 'No Penalty', 'L2', 'Elasticnet']] #this 2d array will contain accuracies for each classifier using the shown format
salaries = [['Linear Regression', 'Predicted Salary', 'Real Salary']]

#Linear Regression with loss functions
lin = LinearRegression().fit(xtrain, ytrain)
ypred = lin.predict(xtest)
salaries.append(['Linear Regression', ypred, ytest])

#Linear Accuracy
accuracies.append(['Linear Regression', lin.score(xtest, ytest), 'N/A', 'N/A'])

#Logistic Regression with loss functions
log = LogisticRegression(max_iter=300).fit(xtrain, ytrain)
ypred = log.predict(xtest)
salaries.append(['Logistic Regression', ypred, ytest])

#Logistic Accuracy
accuracies.append(['Logistic Regression', log.score(xtest, ytest), 'N/A', 'N/A'])

#Perceptron with loss functions
per = Perceptron(max_iter=300).fit(xtrain, ytrain)            
ypred = per.predict(xtest)
salaries.append(['Perceptron', ypred, ytest])

#Perceptron with Regularizations
noPen = accuracy_score(ytest, ypred)

per = Perceptron(max_iter=300, penalty='l2').fit(xtrain, ytrain)            
ypred = per.predict(xtest)
l2 = accuracy_score(ytest, ypred)

per = Perceptron(max_iter=300, penalty='elasticnet').fit(xtrain, ytrain)            
ypred = per.predict(xtest)
elastic = accuracy_score(ytest, ypred)

accuracies.append(['Perceptron', noPen, l2, elastic]) 

#SGDC with loss functions
grad = SGDClassifier(max_iter=300).fit(xtrain, ytrain)           
ypred = grad.predict(xtest)
salaries.append(['SGDC', ypred, ytest])

#SGDC with Regularizations
noPen = accuracy_score(ytest, ypred)

sgdc = SGDClassifier(max_iter=300, penalty='l2').fit(xtrain, ytrain)            
ypred = grad.predict(xtest)
l2 = accuracy_score(ytest, ypred)

sgdc = SGDClassifier(max_iter=300, penalty='elasticnet').fit(xtrain, ytrain)            
ypred = grad.predict(xtest)
elastic = accuracy_score(ytest, ypred)

accuracies.append(['SGDC', noPen, l2, elastic])

#Linear SVM with loss functions
svm = LinearSVC(max_iter=300, dual=False).fit(xtrain, ytrain)           
ypred = svm.predict(xtest)
salaries.append(['Linear SVM', ypred, ytest])

#SVM with Regularizations
noPen = accuracy_score(ytest, ypred)

svm = LinearSVC(max_iter=300, penalty='l2', dual=False).fit(xtrain, ytrain)            
ypred = svm.predict(xtest)
l2 = accuracy_score(ytest, ypred)

accuracies.append(['Linear SVM', noPen, l2, 'N/A'])

#K Means with loss functions
km = KMeans(n_clusters=2, random_state=0).fit(xtrain, ytrain) #use 2 clusters because we only want to know the outcome of death event, which is binary
ypred = km.predict(xtest)
salaries.append(['K Means', ypred, ytest])

accuracies.append(['KMeans', noPen, 'N/A', 'N/A']) #can't use our regularization methods with Kmeans

#Print out results for easy comparison
print('Predicted Salary')
for i in salaries:
    print(i)

print()
print('Accuracy Results')
for i in accuracies:
    print(i)
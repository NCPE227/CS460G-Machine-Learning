from pandas import *
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression, LogisticRegression, Perceptron, SGDClassifier
from sklearn.metrics import accuracy_score, hinge_loss, mean_absolute_error, mean_squared_error, zero_one_loss
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor


#Create dataframes for each dataset
heart = read_csv('heart_failure_clinical_records_dataset.csv', header=None, skiprows=1, delimiter=',') #all data is numerical

#First, we want to try a bunch of classifiers and see which one is best able to predict death events,
#if it's able to predict them at all. For this, we use the Heart Failure dataset and sklearn.

#Convert the Heart Failure dataset into two lists, one containing features and the other containing the death event classifier
index = range(0,12) #we know which columns we want, this is better than typing them manually
x = heart[index].values.tolist()
y = heart[12].values.tolist()

#Split our data into a training and testing set, we do this for the classifiers and the features, preserving their orders
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.3, random_state=1)

#Lets create a list to contain results from each of the tests to printout later for comparison
losses = [['Classifier Name', 'Hinge Loss', 'Zero-One Loss', 'Squared Loss', 'Absolute Loss']] #this 2d array will contain losses for each classified using the shown format
# [ Classifier Name, Hinge Loss, Zero-One Loss, Squared Loss, Absolute Loss ]
accuracies = [['Classifier Name', 'No Penalty', 'L2', 'Elasticnet']] #this 2d array will contain accuracies for each classifier using the shown format

#Linear Regression with loss functions
lin = LinearRegression().fit(xtrain, ytrain)
ypred = lin.predict(xtest)
losses.append(['Linear Regression', 'N/A', 'N/A' , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])

#Linear Accuracy
accuracies.append(['Linear Regression', lin.score(xtest, ytest), 'N/A', 'N/A'])

#Logistic Regression with loss functions
log = LogisticRegression(max_iter=300).fit(xtrain, ytrain)
ypred = log.predict(xtest)
losses.append(['Logistic Regression', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])

#Logistic Accuracy
accuracies.append(['Logistic Regression', log.score(xtest, ytest), 'N/A', 'N/A'])

#Perceptron with loss functions
per = Perceptron(max_iter=300).fit(xtrain, ytrain)            
ypred = per.predict(xtest)
yhinge = per.decision_function(xtest)
losses.append(['Perceptron', hinge_loss(ytest, yhinge), zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])

#Perceptron with Regularizations
noPen = accuracy_score(ytest, ypred)

per = Perceptron(max_iter=300, penalty='l2').fit(xtrain, ytrain)            
ypred = per.predict(xtest)
l2 = accuracy_score(ytest, ypred)

per = Perceptron(max_iter=300, penalty='elasticnet').fit(xtrain, ytrain)            
ypred = per.predict(xtest)
elastic = accuracy_score(ytest, ypred)

accuracies.append(['Perceptron', noPen, l2, elastic]) 

#SGDC with loss functions
grad = SGDClassifier(max_iter=300).fit(xtrain, ytrain)           
ypred = grad.predict(xtest)
yhinge = per.decision_function(xtest)
losses.append(['SGDC', hinge_loss(ytest, yhinge), zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])

#SGDC with Regularizations
noPen = accuracy_score(ytest, ypred)

sgdc = SGDClassifier(max_iter=300, penalty='l2').fit(xtrain, ytrain)            
ypred = grad.predict(xtest)
l2 = accuracy_score(ytest, ypred)

sgdc = SGDClassifier(max_iter=300, penalty='elasticnet').fit(xtrain, ytrain)            
ypred = grad.predict(xtest)
elastic = accuracy_score(ytest, ypred)

accuracies.append(['SGDC', noPen, l2, elastic])

#Linear SVM with loss functions
svm = LinearSVC(max_iter=300, dual=False).fit(xtrain, ytrain)           
ypred = svm.predict(xtest)
yhinge = per.decision_function(xtest)
losses.append(['Linear SVM', hinge_loss(ytest, yhinge), zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])


#SVM with Regularizations
noPen = accuracy_score(ytest, ypred)

svm = LinearSVC(max_iter=300, penalty='l2', dual=False).fit(xtrain, ytrain)            
ypred = svm.predict(xtest)
l2 = accuracy_score(ytest, ypred)

accuracies.append(['Linear SVM', noPen, l2, 'N/A'])

#K Means with loss functions
km = KMeans(n_clusters=2, random_state=0).fit(xtrain, ytrain) #use 2 clusters because we only want to know the outcome of death event, which is binary
ypred = km.predict(xtest)
losses.append(['K Means', 'N/A', zero_one_loss(ytest, ypred), mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])

accuracies.append(['KMeans', noPen, 'N/A', 'N/A']) #can't use our regularization methods with Kmeans

#Since our trees will use different loss functions than the linear classifiers, we should create a new list to contain information so as to have a way
#to print out our results and maintain easy readability
treeacc = [['Classifier Name', 'Loss Function Used', 'Accuracy']] #we will use score for these values

#Decision Tree Classifier
g = DecisionTreeClassifier(criterion='gini')
g = g.fit(xtrain, ytrain)
ypred = g.predict(xtest)
losses.append(['Decision Tree Classifier (Gini)', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Classifier', 'Gini', g.score(xtest, ypred)])

e = DecisionTreeClassifier(criterion='entropy')
e = e.fit(xtrain, ytrain)
ypred = e.predict(xtest)
losses.append(['Decision Tree Classifier (Entropy)', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Classifier', 'Entropy', e.score(xtest, ypred)])

l = DecisionTreeClassifier(criterion='log_loss')
l = l.fit(xtrain, ytrain)
ypred = l.predict(xtest)
losses.append(['Decision Tree Classifier (Log Loss)', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Classifier', 'Log Loss', l.score(xtest, ypred)])

#Decision Tree Regressor
sq = DecisionTreeRegressor(criterion='squared_error')
sq = sq.fit(xtrain, ytrain)
ypred = sq.predict(xtest)
losses.append(['Decision Tree Regressor (Squared Error)', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Regressor', 'Squared Error', sq.score(xtest, ypred)])

fr = DecisionTreeRegressor(criterion='friedman_mse')
fr = fr.fit(xtrain, ytrain)
ypred = fr.predict(xtest)
losses.append(['Decision Tree Regressor (Friedman MSE)', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Regressor', 'Friedman MSE', fr.score(xtest, ypred)])

ae = DecisionTreeRegressor(criterion='absolute_error')
ae = ae.fit(xtrain, ytrain)
ypred = ae.predict(xtest)
losses.append(['Decision Tree Regressor (Absolute Error)', 'N/A', zero_one_loss(ytest, ypred) , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Regressor', 'Absolute Error', ae.score(xtest, ypred)])

p = DecisionTreeRegressor(criterion='poisson')
p = p.fit(xtrain, ytrain)
ypred = p.predict(xtest)
losses.append(['Decision Tree Regressor (Poisson)', 'N/A', 'N/A' , mean_squared_error(ytest, ypred), mean_absolute_error(ytest, ypred)])
treeacc.append(['Decision Tree Regressor', 'Poisson', p.score(xtest, ypred)])

#Print out results for easy comparison
print('Linear Loss Results')
for i in losses:
    print(i)

print()
print('Tree Accuracies')
for i in treeacc:
    print(i)

print()
print('Accuracy Results')
for i in accuracies:
    print(i)
